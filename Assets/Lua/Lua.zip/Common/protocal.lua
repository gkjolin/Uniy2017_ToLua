--Buildin Table
Connect           = '101';	--连接服务器
Exception         = '102';	--异常掉线
Disconnect        = '103';	--正常断线   
Login 			  = '104';	--Login
